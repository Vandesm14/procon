I am a developer (<span class="blue">Rust & TypeScript</span>), music artist, and multimedia enthusiast. I have been programming in TypeScript for <span class="blue">$xp</span> years and switched to loving Rust about <span class="blue">$rust</span> years ago (it happens). Most of my projects start from what I call "_dumb ideas_" that are usually ambitious in the beginning, but can end up working spectacularly.

- [GitHub](https://thedevbird.com/github)
- [Bluesky](https://thedevbird.com/bluesky)
- [YouTube](https://thedevbird.com/youtube)
- [LinkedIn](https://thedevbird.com/linkedin)
- <a id="email">Email</a>
