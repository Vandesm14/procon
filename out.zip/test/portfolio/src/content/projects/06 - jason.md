## Jason

**Source:** [GitHub](https://github.com/vandesm14/jason)

**Website:** [https://jason.thedevbird.com](https://jason.thedevbird.com)

Jason is a dynamic JSON viewer that I built to tabulate and visualize JSON data. It is built with React and TypeScript, and is hosted on GitHub Pages.
