## Classaware

**Website:** [http://classaware.org](http://classaware.org)

A class countdown system I built for my High School. It is still operational and still receives updates. Classaware was the first widespread project I had created in my coding career.
