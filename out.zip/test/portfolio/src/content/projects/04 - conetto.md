## Conetto

**Source:** [GitHub](https://github.com/vandesm14/conetto)

I have always been fascinated by [number stations](https://en.wikipedia.org/wiki/Numbers_station) and one day, I decided to build a Rust library based on it. Conetto provides a set of primitives that allow Text-To-Speech clips to be generated and spliced together in different ways.
