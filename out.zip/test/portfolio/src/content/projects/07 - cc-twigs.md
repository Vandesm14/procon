## CC-Twigs

**Source:** [GitHub](https://github.com/vandesm14/CC-Twigs)

A joint effort of a friend and me to build a collection of packages for **ComputerCraft** (a Minecraft mod). The packages are written completely in Lua, though the hosting server utilizes Deno (TypeScript). Our biggest challenge was and is building an in-game networking system to emulate IP and above.
