# Hi!

I'm Shane, a friendly TypeScript and Rust magician. I like computers and enjoy staring at them for hours on end.

Visit [thedevbird.com](https://thedevbird.com) if you'd like a proper introduction to the work I've done!
