use dotenv::dotenv;
use sqlx::SqlitePool;
use std::{env, error::Error};
use tokio::fs;

#[derive(Debug, sqlx::FromRow)]
struct PostIdSlug {
  id: String,
  slug: Option<String>,
}

const BLOG_URL: &str = "https://blog.airwavegame.com";

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
  dotenv().ok();

  let pool = SqlitePool::connect(
    &env::var("DATABASE_URL").expect("DATABASE_URL not set!"),
  )
  .await?;

  let posts = sqlx::query_as!(PostIdSlug, "SELECT id, slug FROM posts")
    .fetch_all(&pool)
    .await?;

  let mut redirects: Vec<String> = Vec::new();
  for post in posts {
    if let Some(slug) = post.slug {
      redirects.push(format!(
        "rewrite ^/b/{} {}/{} permanent;",
        post.id, BLOG_URL, slug
      ));
    }
  }

  let redirects_content = redirects.join("\n");
  fs::write("site/blog.redirects.conf", redirects_content)
    .await
    .expect("Unable to write file");
  println!("Done.");

  Ok(())
}
