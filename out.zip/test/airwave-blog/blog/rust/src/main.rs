use std::{env, error::Error, fs, time::SystemTime};

use dotenv::dotenv;
use itertools::Itertools;
use sqlx::SqlitePool;
use time::{OffsetDateTime, PrimitiveDateTime};
use turborand::TurboRand;

pub fn now() -> PrimitiveDateTime {
  let system_time = SystemTime::now();
  let odt: OffsetDateTime = system_time.into();

  PrimitiveDateTime::new(odt.date(), odt.time().replace_millisecond(0).unwrap())
}

pub fn id() -> String {
  let rng = turborand::rng::Rng::new();
  let id: String = (0..10)
    .map(|_| {
      let is_digit = rng.chance(0.3);
      if is_digit {
        (rng.u8(0..=9) + b'0') as char
      } else {
        (rng.u8(0..=25) + b'a') as char
      }
    })
    .collect();
  id
}

#[derive(Debug, Clone, PartialEq, sqlx::FromRow)]
struct Post {
  pub id: String,
  pub slug: Option<String>,
  pub modify_token: Option<String>,
  pub text_appearance: String,
  pub language: Option<String>,
  pub rtl: Option<i64>,
  pub privacy: i64,
  pub owner_id: Option<i64>,
  pub collection_id: Option<i64>,
  pub pinned_position: Option<i64>,
  pub created: PrimitiveDateTime,
  pub updated: PrimitiveDateTime,
  pub view_count: i64,
  pub title: String,
  pub content: String,
}

impl Default for Post {
  fn default() -> Self {
    Post {
      id: String::new(),
      slug: None,
      modify_token: None,
      text_appearance: "norm".to_owned(),
      language: Some("en".to_owned()),
      rtl: None,
      privacy: 0,
      owner_id: Some(1),
      collection_id: Some(1),
      pinned_position: None,
      created: now(),
      updated: now(),
      view_count: 0,
      title: String::new(),
      content: String::new(),
    }
  }
}

impl Post {
  fn new(
    title: impl AsRef<str>,
    slug: impl AsRef<str>,
    content: impl AsRef<str>,
    is_draft: bool,
  ) -> Self {
    Self {
      id: id(),
      slug: Some(slug.as_ref().to_owned()),
      title: title.as_ref().to_owned(),
      content: content.as_ref().to_owned(),
      collection_id: if is_draft { None } else { Some(1) },
      ..Default::default()
    }
  }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
  tracing_subscriber::fmt::init();

  dotenv().ok();

  let pool = SqlitePool::connect(
    &env::var("DATABASE_URL").expect("DATABASE_URL not set!"),
  )
  .await?;
  for (is_draft, file) in fs::read_dir("blog/posts")?
    .flatten()
    .filter(|p| p.file_name().to_str().unwrap().ends_with(".md"))
    .map(|p| {
      let is_draft = p.file_name().to_str().unwrap().ends_with(".draft.md");

      (is_draft, p)
    })
  {
    let title = file
      .file_name()
      .to_str()
      .unwrap()
      .replace("blog/posts/", "");
    let title = title
      .split(" - ")
      .skip(1)
      .join(" - ")
      .replace(".md", "")
      .replace(".draft", "");

    // Remove spaces
    let mut slug = title.replace(" ", "-").to_lowercase();
    while slug.contains("--") {
      slug = slug.replace("--", "-");
    }

    let content = fs::read_to_string(file.path())?;
    let content =
      content.replace("../images/", "https://blog.airwavegame.com/img/blog/");

    let mut post = Post::new(title, slug, content, is_draft);
    let from_slug: Vec<_> =
      sqlx::query!("select id from posts where slug = $1 limit 1;", post.slug)
        .fetch_all(&pool)
        .await?;
    let from_title: Vec<_> = sqlx::query!(
      "select id from posts where title = $1 limit 1;",
      post.title
    )
    .fetch_all(&pool)
    .await?;

    let existing_id = from_slug
      .first()
      .map(|x| x.id.clone())
      .or_else(|| from_title.first().map(|x| x.id.clone()));

    post.id = existing_id.clone().unwrap_or(post.id).clone();

    if existing_id.is_some() {
      let existing_post = sqlx::query!(
        "select content, collection_id from posts where id = $1 limit 1;",
        post.id
      )
      .fetch_one(&pool)
      .await?;

      if existing_post.content == post.content
        && existing_post.collection_id == post.collection_id
      {
        tracing::warn!(
          "no updates to ({}): {}",
          post.id,
          file.file_name().to_str().unwrap()
        );
        continue;
      }

      sqlx::query!(
        "update posts set updated = $2, content = $3, collection_id = $4 where id = $1;",
        post.id,
        post.updated,
        post.content,
        post.collection_id,
      )
      .execute(&pool)
      .await?;
      tracing::info!(
        "updated post ({}): {}",
        post.id,
        post.slug.unwrap_or_default()
      );
    } else {
      tracing::info!("creating new post: {}", post.id);
      sqlx::query!(
        "insert into posts (id, slug, text_appearance, language, privacy, owner_id, collection_id, created, updated, view_count, title, content) values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12);",
        post.id,
        post.slug,
        post.text_appearance,
        post.language,
        post.privacy,
        post.owner_id,
        post.collection_id,
        post.created,
        post.updated,
        post.view_count,
        post.title,
        post.content
      )
      .execute(&pool)
      .await?;
      tracing::info!(
        "created post ({}): {}",
        post.id,
        post.slug.unwrap_or_default()
      );
    }
  }

  Ok(())
}
