use dotenv::dotenv;
use sqlx::SqlitePool;
use std::{env, error::Error};

#[derive(Debug, sqlx::FromRow)]
struct PostIdSlug {
  id: String,
  slug: Option<String>,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
  dotenv().ok();

  let pool = SqlitePool::connect(
    &env::var("DATABASE_URL").expect("DATABASE_URL not set!"),
  )
  .await?;

  let posts = sqlx::query_as!(PostIdSlug, "SELECT id, slug FROM posts")
    .fetch_all(&pool)
    .await?;

  for post in posts {
    println!("({}) {}", post.id, post.slug.unwrap_or_default());
  }

  Ok(())
}
