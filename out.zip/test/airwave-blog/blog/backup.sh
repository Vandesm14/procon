#!/usr/bin/env bash
# Get the current date in YYYY_MM_DD format
DATE=$(date +'%Y_%m_%d')

# Set the filename with the desired format
FILENAME="blog/backups/${DATE}.db"

scp airwave:/var/www/blog/writefreely/writefreely.db $FILENAME
cp $FILENAME writefreely.db

gzip $FILENAME
