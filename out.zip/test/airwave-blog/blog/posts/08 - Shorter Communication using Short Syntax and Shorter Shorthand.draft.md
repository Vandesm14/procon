*Written by: [TheDevBird](https://bsky.app/profile/thedevbird.bsky.social)*

#devlog

---

When Airwave began, my goal with was to take a leap with an ambitious plan: Creating voice-first, unbounded communication with aircraft, mirroring exactly how real controllers interact with aircraft on their frequency.

Most ATC sims force you into hard-coded syntax, forcing you to learn a bespoke form of communication that may or may not mirror real patterns. This distances those games from realism, no matter how close-to-real their procedures or interfaces are. You end up with a learning curve that is based solely around the command syntax along with how the sim might handle certain procedures, rather than being able to learn ATC at its core. Don't get me wrong, the command-style pattern of communication is great for a fast-paced workflow such as air traffic controll.

Actually, that's cool. What if we pivoted did that too?

<!--more-->

## Adding a text box

When I showed Airwave to one of my friends, they thought it was really cool. But they weren't fully sold on the idea of using their voice, maybe due to the keyboard shortcuts or simply due to their playing style. They asked me to add a text box, a feature I wanted to add for some time, but was buried under higher priority tasks.

The task sat for a while, collecting dust, until I finally caved and added a special route and UI for text-based communications. It used the same LLM configuration so there was no loss there, aside from having to type out your commands instead of speak them.

Honestly, it wasn't that bad either. The "chat box" looked so much better with a text input to go along.

## Adding more to the text box

Many months later, after looking deeper into the market of ATC sims and similar games, I found that though the text-based workflow wasn't hyper-realistic, it allowed for a more concrete and fast method of communication.