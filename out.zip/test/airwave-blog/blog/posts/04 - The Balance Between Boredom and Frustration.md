*Written by [Leon]*.
*Licensed under [CC BY-SA 4.0]*.

#aside

---

[*Expanding to infinite horizons*][expanding-to-infinite-horizons] briefly lays out why ***centre*** was abandoned. Let's see why ***centre*** felt as though you were ***doing chores***.

[Leon]: https://leonski.dev
[CC BY-SA 4.0]: https://creativecommons.org/licenses/by-sa/4.0
[expanding-to-infinite-horizons]: https://blog.airwavegame.com/endless-skies-expanding-to-infinite-horizons

<!--more-->

## Simpler times

It all started with ***approach***. Aircraft would *just show up out of nowhere* around the edge of the airspace. You were tasked with leading them towards and lining them up with a runway, eventually clearing them to land once it made sense to.

Naturally, ***departure*** was added shortly after. Somewhat akin to ***approach***, aircraft would *just show up out of nowhere*, but this time on a runway. You then had to clear them for take-off and lead them out of the airspace.

'Twas fun.

## Grounds for fun

Instead of ***departures*** that *just show up out of nowhere* on runways, it would be fun to tie ***approach*** and ***departure*** together. Thus, ***ground*** was born.

Your goal was to taxi landing aircraft, handed over by ***approach***, around the airport to available gates. Meanwhile, parked aircraft could become ready to ***depart***. In such a case, you would need to taxi them to a runway, clear them for take-off, and hand them over to ***departure***.

'Twas also fun.

## Wax wings

Since ***ground*** was enjoyable, expanding outwards seemed like the obvious next step. Your task would be to command the masses of aircraft travelling between airspaces, also known as ***centre***.

'Twas a chore.

## Splash

Let's see what makes these so different.

With ***approach*** and ***departure***, you were likely handling eight-or-so aircraft at a time. Each one created little puzzles that needed to be solved in order for the whole to operate smoothly. ***Ground*** tied into them by requiring good sequencing and communication so that they could flow smoothly as a cohesive unit.

With ***centre***, you were handling tens of aircraft at a time, none of which needed much thought. At most, all you would need to do is plan out a route and tell the aircraft to follow it, which isn't much of a puzzle for our spatially-adept brains. In addition, there was no game-related reason to communicate with the others.

In the first case, semi-frequent puzzles kept you from becoming bored, without being so common as to become frustrating; it was a fun set of mini-challenges to overcome. However, ***centre*** was a consistent onslaught of menial tasks that needed little in the way of thought; it was an ever-growing list of mind-numbing chores.

As you can imagine, ***centre*** was swiftly dropped.

## Afterword

Play-testing is essential for catching these *good on paper* ideas that *feel bad* to play in actuality. In a team, it's important to be able to tell someone that their idea sucks, and be told the same. It is what it is, figure out what went wrong and use that knowledge thenceforth, otherwise the mistake was for nought.

As always, have fun.
