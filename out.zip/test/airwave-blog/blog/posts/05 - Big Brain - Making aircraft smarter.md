*Written by: [TheDevBird](https://bsky.app/profile/thedevbird.bsky.social)*

#devlog

---

I don't know if you've played Airwave recently but the aircraft were dumb. When they were instructed to land, they would turn almost 90 degrees toward the localizer, close to perpendicular. Then, they would go back and forth, overshooting it as they went. And on the ground, they were not aware of each other, never stopping to avoid a crash. This would result in two or more aircraft occupying the same spot if the ground controller wasn't paying attention.

**Immersion ruined.** *Let's fix that.*

<!--more-->

## Landing but better

### Follow this dot

Landing is difficult problem. An aircraft needs to act realistically, as the user intends. When you line them up with the localizer, ideally, they should wait until they need to turn, then do so. Only changing their heading, taking over correction, to ensure that they are lined up with the localizer.

The version of landing before the one we will go over in this devlog was very simple: find the closest point on the localizer, move it towards the runway slightly, then have the aircraft point towards it. Moving it forward forced the aircraft to not only line up with the localizer, but keep it pointed towards the runway. Having it only a fraction of a nautical mile in front of the aircraft meant that it would have to make sharp corrections, quickly placing it on course.

We tested further padding distances but they all resulted in subpar alignment with the localizer.

![aircraft landing; the trail showing that it had overshot](../images/05-devlog-big-brain/aircraft-overshooting.png)

*Using the old landing algorithm, aircraft would overshoot easily, but they would still make it to the localizer eventually.*

### Real pilots aren't computers

Obviously, real pilots aren't computers. They're able to make informed decisions about their position based on the localizer and turn only when they need to. In the real world, they can approach the localizer with a perfect turn to lineup directly with it, without under or overshooting.

But of course, this is just human intuition, and implementing this into Airwave required complex implementation and tuning. One problem we realized early on was that an aircraft should always stay pointed at the the localizer until it needs to turn. If an air traffic controller sets an aircraft on course for the localizer, it should not change the heading unless it knows that it won't be lined up properly.

We started out with a one-shot algorithm: find how much it needs to turn to align, how long it will take to make that turn, and how far from the localizer to initiate the turn. This worked well, but had a few drawbacks.

Once a turn was initiated, the target heading of the aircraft was set to the heading of the runway. This being a once-only change, it couldn't correct for any present changes to its speed or heading during the turn if it was already made.

If a controller wanted to tweak the speed of an aircraft during localizer intercept, it would change the distance of when to initiate the turn while a turn was being made. But since a turn is one-shot, the algorithm couldn't stop a turn to correct for any changes on the initial parameters.

![aircraft overshooting the localizer but holding steady to runway heading](../images/05-devlog-big-brain/aircraft-overshooting-but-runway-heading.png)

*The aircraft started its turn too late due to a speed change which it couldn't account for. Now, the aircraft is flying runway heading but not lined up with the localizer.*

### Refining the brain

We needed a way for the aircraft to:

1. Keep its initial heading until it needed to make the turn
2. Make the turn
3. Correct for any inaccuracies

Importantly, each of these steps needed to run in sequence, ensuring that the turn and correction parts were separate. We didn't want the aircraft to make any adjustments on its own unless it needed to. This allows the controller to know that the heading an aircraft is flying will only change right before it hits the localizer in time. So, we implemented a state-based system where an aircraft would understand what phase of the landing procedure it was in, allowing it to sustain its heading until the turn, then take over if it needed to correct.

![an aircraft about to intercept the localizer](../images/05-devlog-big-brain/aircraft-ready-to-turn.png)
![an aircraft turning to line up with the localizer](../images/05-devlog-big-brain/aircraft-turning.png)
![an aircraft on the localizer](../images/05-devlog-big-brain/aircraft-localizer.png)

*Note the "TRN" and "LOC" labels that indicate what state of the landing an aircraft is in.*

*PS: Please ignore the choppy trails, I have no idea why they're doing that. Must be from the testing set-up I was using.*

## Taxiing like cars

### Driver-ful behavior

Another issue we wanted to fix was that aircraft on the ground had no spatial awareness. They literally had no idea if an aircraft was in front of them or if they were about to crash. We opted to fix this by adding a stateful system for taxiing.

![taxiing aircraft almost crash](../images/05-devlog-big-brain/aircraft-almost-colliding.png)

*Note: This screenshot was taken from an older version of Airwave with our old airport, but still illustrates the issue of "dumb" aircraft.*

This "brain" is much simpler than the landing system, only needing to check for a possible collision (if aircraft in front and within a certain distance). Though, the interface between this system and the player was a little tricky.

We needed to figure out how to allow the player to force an aircraft to continue taxiing if it was safe, despite the system thinking a collision was imminent. We got this working via a sort of state machine where the aircraft would stop if a collision was found. If the player told the aircraft to continue, a flag would be set to override the hold. Once the collision was avoided, the state would be re-armed.

Another issue we ran into was how we could keep an aircraft stopped, in special conditions, so they wouldn't resume taxi once the collision was avoided. We added another flag to say if an aircraft should stay stopped regardless of collision or not. This was activated when it reached the end of its waypoints or hit a hold-short waypoint. Plus, if the player tells an aircraft to hold, that also enforces it stay put.

### Starting a conga line

With this new change, players can stack aircraft in a queue before a runway. Aircraft will automatically stop and start as the aircraft leave the queue after being taken off. All of this happens automatically, alleviating the player from having to constantly give aircraft new instructions to ensure they don't collide.

![aircraft holding when one is in front](../images/05-devlog-big-brain/aircraft-hold-in-front.png)
![runway queue conga line](../images/05-devlog-big-brain/runway-conga-line.png)

As you can see, efficient queuing can be done, managed automatically by the aircraft.

## Fin

Both of these changes will introduce a more intuitive behavior of aircraft, alleviating a little stress and focus from both approach and ground controllers. Airwave's core mission is to create a realistic experience, emulating the intuition of real pilots, allowing players to work like real-world air/ground controllers within a welcoming and adaptive environment.
